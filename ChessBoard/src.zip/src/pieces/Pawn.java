package pieces;

import board.ChessBoard;

import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.swing.*;

public class Pawn extends Piece{

    private static final int PIECE_VALUE = 1;

    private boolean enPassantDangerFromLeft = false;// if this pawn can be taken using en passant from opponent pawn in the left
    private boolean enPassantDangerFromRight = false;// if this pawn can be taken using en passant from opponent pawn in the right
    private boolean enPassantVulnerable = false; // set only when this pawn actually double-stepped
    private boolean enPassantAllowed = false; //if this pawn is allowed to en passant an opponent pawn

    public Pawn(Character chessCol, int chessRow, boolean white, ChessBoard chessBoard){
        setChessCol(chessCol);
        setChessRow(chessRow);

        if (white)
            setIdentification(PieceIdentification.W_PAWN);
        else
            setIdentification(PieceIdentification.B_PAWN);

        chessBoard.insertPiece(chessCol,chessRow,this);

    }


    @Override
    public void moveCheck(ChessBoard chessBoard) {


        // ALWAYS clear the list first to prevent duplicating old moves
        if (validMoveList != null) {
            validMoveList.clear();
        }


        int col = chessColToIndex(getChessCol());
        int row = Piece.chessRowToIndex(getChessRow());

        Piece[][] refBoard = chessBoard.getBoard();

        //6 possible moves for pawn
        int[][] tempMoveSet;
        boolean[] tempValidMoveSet = new boolean[6];

        //direction is different for white and black so moveset has to be initiated differently
        if (getIdentification().isBlack()) {

            tempMoveSet = new int[][]{
                    //one square forward, 2 square forward, left capture, right capture, en Passant to the left, en Passant to the right
                    {row + 1, col}, {row + 2, col}, {row + 1, col - 1}, {row + 1, col + 1}, {-1, -1}, {-1, -1}
            };
        } else {

            tempMoveSet = new int[][]{
                    //one square forward, 2 square forward, left capture, right capture, en Passant to the left, en Passant to the right
                    {row - 1, col}, {row - 2, col}, {row - 1, col - 1}, {row - 1, col + 1}, {-1, -1}, {-1, -1}
            };

        }

        //crude way to check if general the moves exist on the board, en passant moves are calculated later in the code
        for (int i = 0; i < 4; i++) {
            if (tempMoveSet[i][1] < 8 && tempMoveSet[i][1] >= 0 && tempMoveSet[i][0] < 8 && tempMoveSet[i][0] >= 0) {
                tempValidMoveSet[i] = true;
            }
        }

        //one square move logic
        if (tempValidMoveSet[0]) {
            int toRow = tempMoveSet[0][0];
            int toCol = tempMoveSet[0][1];

            if (refBoard[toRow][toCol] == null) { //because the validMoveSet can be assumed to be filled with trues, we just flip it to false again if the move is blocked by another piece
                validMoveList.add(new int[]{toRow,toCol});
            } else {
                tempValidMoveSet[0] = false;
                tempValidMoveSet[1] = false; //if the 1 square move is blocked the 2 square move must also be blocked so we can flip it to false as well
            }
        }

        // 2 square move logic
        if (tempValidMoveSet[1] && tempValidMoveSet[0]) { //for 2 square to be valid, 1 square move must be valid from the before if check
            int toRow = tempMoveSet[1][0];
            int toCol = tempMoveSet[1][1];

            if (isOnStartingRow()) { //uses a method to see if the pawn is in the starting row
                if (refBoard[toRow][toCol] == null) {
                    validMoveList.add(new int[]{toRow,toCol});
                }
            }
        }

        //capturing a piece logic
        if (tempValidMoveSet[2] ) {
            int toRow2 = tempMoveSet[2][0]; // capture to the left
            int toCol2 = tempMoveSet[2][1];

            if (refBoard[toRow2][toCol2] != null) { //if there is a piece present in the left immediate diagonal pawn can move there
                if (getIdentification().isWhite() != refBoard[toRow2][toCol2].getIdentification().isWhite()) { // must be an opponent piece
                    validMoveList.add(new int[]{toRow2,toCol2});
                }
            } 
        }
        if (tempValidMoveSet[3]){
            int toRow3 = tempMoveSet[3][0]; // capture to the right
            int toCol3 = tempMoveSet[3][1];

            if (refBoard[toRow3][toCol3] != null) { //if there is a piece present in the right immediate diagonal pawn can move there
                if (getIdentification().isWhite() != refBoard[toRow3][toCol3].getIdentification().isWhite()) { // must be an opponent piece
                    validMoveList.add(new int[]{toRow3,toCol3});
                }
            }
        }


        //en passant to the left logic
        if ((col - 1) >= 0 && col - 1 < 8) {
            Piece leftPiece = refBoard[row][col - 1];
            if (PieceIdentification.isPawn(leftPiece)) {
                Pawn p = (Pawn) leftPiece;
                boolean isOpponent = p.getIdentification().isWhite() != getIdentification().isWhite();
                if (isOpponent && p.isEnPassantVulnerable()) {
                    int targetRow = getIdentification().isWhite() ? row - 1 : row + 1;
                    int targetCol = col - 1;
                    if (refBoard[targetRow][targetCol] == null) {
                        validMoveList.add(new int[]{targetRow,targetCol});
                        tempValidMoveSet[4] = true;
                    }
                }
            }
        }

        //en passant logic to the right
        if ((col + 1) >= 0 && col + 1 < 8) {
            Piece rightPiece = refBoard[row][col + 1];
            if (PieceIdentification.isPawn(rightPiece)) {
                Pawn p = (Pawn) rightPiece;
                boolean isOpponent = p.getIdentification().isWhite() != getIdentification().isWhite();
                if (isOpponent && p.isEnPassantVulnerable()) {
                    int targetRow = getIdentification().isWhite() ? row - 1 : row + 1;
                    int targetCol = col + 1;
                    if (refBoard[targetRow][targetCol] == null) {
                        validMoveList.add(new int[]{targetRow,targetCol});
                        tempValidMoveSet[5] = true;

                    }
                }
            }
        }

        /* 
        int count = 0; //the total valid move number
        for (int i = 0; i < 6; i++) {
            if (tempValidMoveSet[i]) {
                count++;
            }
        } */

        //System.out.println("\nPawn valid move count : "+count+"\n");

        //System.out.print("Pawn : ");
        //Global.print1D(tempValidMoveSet);


    }

    @Override
    public void movePiece() {

    }

    @Override
    public String toString(){
        if (getIdentification().isWhite())
            return " wP ";
        else
            return " bP ";


    }

    //a method used to check if the pawn is in the starting row
    public boolean isOnStartingRow(){

        if (getIdentification().isWhite() && chessRowToIndex(getChessRow()) == 6 ){
            return true;
        }
        if (getIdentification().isBlack() && chessRowToIndex(getChessRow()) == 1 ){
            return true;
        }

        return false;
    }

    // a method used to check if a pawn can be taken using en passant
    public boolean[] enPassantDangerCheck(ChessBoard chessBoard){

        int dangerRow ; //the row where an en passant could happen, different for white and black pieces
        Piece[][] refBoard = chessBoard.getBoard();
        int col = chessColToIndex(getChessCol());

        if(getIdentification().isWhite()){ // if white
            dangerRow = 4;

            if (col+1 >= 0 && col+1 <8){ // column must be valid
                if (PieceIdentification.isPawn(refBoard[dangerRow][col+1]) && refBoard[dangerRow][col+1].getIdentification().isBlack()){ //if there is another black pawn to the right
                    enPassantDangerFromRight = true;
                    //System.out.println("this piece could be enPassant'ed next move : "+refBoard[dangerRow][col].getChessCol()+refBoard[dangerRow][col].getChessRow());
                    ((Pawn) refBoard[dangerRow][col+1]).enPassantAllowed = true; //gives said pawn en passant privileges

                }
            }

            if (col-1 >= 0 && col-1 <8){//column must be valid
                if (PieceIdentification.isPawn(refBoard[dangerRow][col-1]) && refBoard[dangerRow][col-1].getIdentification().isBlack()){//if there is another black pawn to the left
                    enPassantDangerFromLeft = true;
                    //System.out.println("this piece could be enPassant'ed next move : "+refBoard[dangerRow][col].getChessCol()+refBoard[dangerRow][col].getChessRow());
                    ((Pawn) refBoard[dangerRow][col-1]).enPassantAllowed = true; //gives said pawn en passant privileges

                }
            }



        }  else { //if black
            dangerRow = 3;

            if (col+1 >= 0 && col+1 <8){//column must be valid
                if (PieceIdentification.isPawn(refBoard[dangerRow][col+1]) && refBoard[dangerRow][col+1].getIdentification().isWhite()){//if there is another white pawn to the right
                    enPassantDangerFromRight = true;
                    //System.out.println("this piece could be enPassant'ed next move : "+refBoard[dangerRow][col].getChessCol()+refBoard[dangerRow][col].getChessRow());
                    ((Pawn) refBoard[dangerRow][col+1]).enPassantAllowed = true; //gives said pawn the en passant privileges

                }
            }

            if (col-1 >= 0 && col-1 <8){
                if (PieceIdentification.isPawn(refBoard[dangerRow][col-1]) && refBoard[dangerRow][col-1].getIdentification().isWhite()){//if there is another white pawn to the left
                    enPassantDangerFromLeft = true;
                    //System.out.println("this piece could be enPassant'ed next move : "+refBoard[dangerRow][col].getChessCol()+refBoard[dangerRow][col].getChessRow());
                    ((Pawn) refBoard[dangerRow][col-1]).enPassantAllowed = true;//gives said pawn the en passant privileges

                }
            }
        }
        return new boolean[]{enPassantDangerFromLeft,enPassantDangerFromRight};
    }

    // a method used to promote a pawn
    public void promote(ChessBoard chessBoard){

        int lastRow ;//last row differs for white and black
        boolean isWhite = false;//to check what color the pawn is
        Piece[][] refBoard = chessBoard.getBoard();

        if(getIdentification().isWhite()){
            lastRow = 0;//for white last row is 0 as white moves 7 -> 0
            isWhite = true;
        }  else {
            lastRow = 7;//for black the last row is 7 as black moves 0 -> 7
        }


        for (int i = 0; i < 8; i++){ //checks the whole last row to see if there is a pawn present
            if(PieceIdentification.isPawn(refBoard[lastRow][i])){
                refBoard[lastRow][i] = null; //sets the pawn piece square to null

                String[] options = { //promotion options
                        "Knight",
                        "Bishop",
                        "Rook",
                        "Queen",
                };

                int choice = JOptionPane.showOptionDialog(//the message box to choose which promotion happens
                        null,
                        "Choose the promotion:",
                        "Promotion",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        options,
                        options[3]//default is queen
                );

                switch (choice){ //the promotions
                    case 0 :
                        refBoard[lastRow][i] = new Knight(colToChessCol(i),rowToChessRow(lastRow),isWhite,chessBoard);
                        break;
                    case 1 :
                        refBoard[lastRow][i] = new Bishop(colToChessCol(i),rowToChessRow(lastRow),isWhite,chessBoard);
                        break;
                    case 2 :
                        refBoard[lastRow][i] = new Rook(colToChessCol(i),rowToChessRow(lastRow),isWhite,chessBoard);
                        break;
                    case 3 :
                        refBoard[lastRow][i] = new Queen(colToChessCol(i),rowToChessRow(lastRow),isWhite,chessBoard);
                        break;
                    default :
                        refBoard[lastRow][i] = new Queen(colToChessCol(i),rowToChessRow(lastRow),isWhite,chessBoard);
                }

                chessBoard.setBoard(refBoard);//the board is updated

            }
        }



    }
    //getters
    public boolean getEnPassantAllowed(){
        return enPassantAllowed;
    }

    public boolean isEnPassantVulnerable() { return enPassantVulnerable; }

    //setters
    public void setEnPassantVulnerable(boolean v) { enPassantVulnerable = v; }

    //a method used to release a pawn from en passant danger if the opponent doesn't use en passant in his immediate turn
    public void releaseEnPassantDanger(){
        enPassantDangerFromLeft = false;
        enPassantDangerFromRight = false;
    }

    //a method used to revoke en passant privileges from a pawn if the player doesn't use en passant in his immediate turn
    public void revokeEnPassantAllowed(){
        enPassantAllowed = false;
    }
}
